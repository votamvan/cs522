docker run --hostname=quickstart.cloudera --privileged=true -it -v $(pwd):/cs522/ -p 8888:8888 \
           -w /cs522 cloudera/quickstart /usr/bin/docker-quickstart

