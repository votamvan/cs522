cd project-mapreduce

echo "=====*===== Average =====*====="
./run average

echo "=====*===== InMapperWordCount =====*====="
./run inmapper

echo "=====*===== PAIR approach =====*====="
./run pair

echo "=====*===== STRIPE approach =====*====="
./run stripe

echo "=====*===== HYBRID approach =====*====="
./run hybrid

