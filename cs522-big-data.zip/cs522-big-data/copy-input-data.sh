hadoop fs -mkdir /bd/ /bd/apache/ /bd/comatrix/ /bd/comatrix/input/
hadoop fs -put input/*_log /bd/apache/
hadoop fs -put input/test-data.txt /bd/comatrix/input/
hadoop fs -put input/diamonds.csv /bd/

